// আপনার WhatsApp নম্বর ও TikTok লিংক এখানে পরিবর্তন করুন। বাংলাদেশের 01993538640 নম্বরটি আন্তর্জাতিক ফরম্যাটে রাখা হয়েছে।
window.SITE_CONFIG = {
  siteName: "ALIF CREATOR HUB",
  whatsappNumber: "8801993538640",
  tiktokUrl: ""
};
