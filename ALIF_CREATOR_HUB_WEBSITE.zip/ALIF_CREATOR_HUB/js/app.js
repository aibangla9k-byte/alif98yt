(() => {
const cfg=window.SITE_CONFIG||{}, products=window.PRODUCTS||[];
const grid=document.getElementById("grid"), back=document.getElementById("backdrop");
const money=n=>`${cfg.currency||"৳"}${Number(n).toLocaleString("en-US")}`;
const wa=msg=>`https://wa.me/${String(cfg.whatsappNumber||"8801993538640").replace(/\D/g,"")}?text=${encodeURIComponent(msg)}`;
const names={course:"কোর্স",channel:"চ্যানেল",service:"সার্ভিস",digital:"ডিজিটাল প্রোডাক্ট"};
function render(filter="all"){
const list=products.filter(p=>filter==="all"||p.category===filter);
grid.innerHTML=list.map(p=>`<article class="card" tabindex="0" role="button" data-id="${p.id}"><div class="icon">${p.icon}</div><span class="tag">${p.tag||names[p.category]}</span><h3>${p.name}</h3><p>${p.description}</p><div class="cardbottom"><strong>${money(p.price)}</strong><span>দাম ও বিস্তারিত ↗</span></div></article>`).join("");
grid.querySelectorAll(".card").forEach(c=>{const open=()=>show(products.find(p=>p.id===c.dataset.id));c.addEventListener("click",open);c.addEventListener("keydown",e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();open()}})});
}
function show(p){if(!p)return;document.getElementById("mi").textContent=p.icon;document.getElementById("mc").textContent=names[p.category]||"প্রোডাক্ট";document.getElementById("mt").textContent=p.name;document.getElementById("md").textContent=p.description;document.getElementById("mp").textContent=money(p.price);document.getElementById("order-wa").href=wa(`আসসালামু আলাইকুম, আমি "${p.name}" অর্ডার করতে চাই। ওয়েবসাইটে দেখানো দাম: ${money(p.price)}। অনুগ্রহ করে বিস্তারিত জানাবেন।`);back.hidden=false}
document.getElementById("close").addEventListener("click",()=>back.hidden=true);back.addEventListener("click",e=>{if(e.target===back)back.hidden=true});document.addEventListener("keydown",e=>{if(e.key==="Escape")back.hidden=true});
document.querySelectorAll("#filters button").forEach(b=>b.addEventListener("click",()=>{document.querySelectorAll("#filters button").forEach(x=>x.classList.remove("active"));b.classList.add("active");render(b.dataset.filter)}));
["top-wa","hero-wa","contact-wa"].forEach(id=>document.getElementById(id).href=wa("আসসালামু আলাইকুম, আপনার ওয়েবসাইটের কোর্স ও সার্ভিস সম্পর্কে জানতে চাই।"));
const t=document.getElementById("tiktok");if(cfg.tiktokUrl)t.href=cfg.tiktokUrl;else t.addEventListener("click",e=>{e.preventDefault();alert("js/config.js ফাইলে আপনার TikTok লিংক বসান।")});
document.getElementById("year").textContent=new Date().getFullYear();render();
})();