// নিচের price সংখ্যাগুলো নমুনা মূল্য। নিজের সঠিক দাম বসান।
window.PRODUCTS = [
{id:"cartoon-course",name:"কার্টুন ভিডিও কোর্স",category:"course",tag:"জনপ্রিয়",icon:"🎬",price:499,description:"AI দিয়ে কার্টুন ভিডিও তৈরি, প্রম্পট লেখা ও Shorts বানানোর বেসিক শেখার কোর্স।"},
{id:"youtube-channel",name:"YouTube চ্যানেল সেল",category:"channel",tag:"চ্যানেল",icon:"▶️",price:2500,description:"বিক্রির জন্য থাকা চ্যানেলের তথ্য ও শর্ত WhatsApp-এ জেনে নিন। চ্যানেলের তথ্য ও মালিকানা যাচাই করুন।"},
{id:"video-editing",name:"ভিডিও এডিটিং কোর্স",category:"course",tag:"কোর্স",icon:"✂️",price:399,description:"CapCut, Shorts এডিটিং, ট্রানজিশন, সাবটাইটেল ও বেসিক ইফেক্ট শেখার কোর্স।"},
{id:"voice-over",name:"Voice Over কোর্স",category:"course",tag:"কোর্স",icon:"🎙️",price:299,description:"স্ক্রিপ্ট পড়া, ভয়েস রেকর্ড করা ও ভিডিওতে ভয়েস বসানোর বেসিক।"},
{id:"ai-video",name:"AI ভিডিও কোর্স",category:"course",tag:"AI",icon:"🤖",price:499,description:"AI দিয়ে ভিডিও আইডিয়া, ইমেজ/ভিডিও প্রম্পট এবং ছোট ভিডিও তৈরির ওয়ার্কফ্লো।"},
{id:"thumbnail-logo",name:"Thumbnail ও Logo ডিজাইন",category:"service",tag:"ডিজাইন",icon:"🎨",price:199,description:"YouTube থাম্বনেইল, প্রোফাইল লোগো বা ব্যানার ডিজাইনের জন্য আপনার চাহিদা জানান।"},
{id:"digital-pack",name:"ডিজিটাল প্রোডাক্ট প্যাক",category:"digital",tag:"ডাউনলোড",icon:"📦",price:99,description:"ভিডিও আইডিয়া, স্ক্রিপ্ট, প্রম্পট ও কনটেন্ট প্ল্যানের ডিজিটাল প্যাক।"},
{id:"youtube-setup",name:"YouTube চ্যানেল সেটআপ",category:"service",tag:"সার্ভিস",icon:"🚀",price:299,description:"চ্যানেলের বেসিক সেটআপ, About লেখা ও প্রাথমিক ব্র্যান্ডিংয়ে সহায়তা।"},
{id:"shorts-editing",name:"YouTube Shorts এডিটিং",category:"service",tag:"সার্ভিস",icon:"📱",price:150,description:"আপনার ফুটেজ দিয়ে ছোট ভিডিও এডিটিং সার্ভিস। চূড়ান্ত দাম কাজের ওপর নির্ভর করতে পারে।"},
{id:"prompt-pack",name:"AI Video Prompt Pack",category:"digital",tag:"ডিজিটাল",icon:"📝",price:79,description:"AI ভিডিও তৈরির জন্য প্রম্পটের ডিজিটাল সংগ্রহ।"},
{id:"islamic-video",name:"Islamic Voice Over গাইড",category:"digital",tag:"গাইড",icon:"🌙",price:199,description:"ইসলামিক ভিডিওর স্ক্রিপ্ট পরিকল্পনা, ভয়েসওভার ও এডিটিং ওয়ার্কফ্লোর গাইড।"},
{id:"channel-review",name:"YouTube Channel Review",category:"service",tag:"সার্ভিস",icon:"📊",price:199,description:"চ্যানেলের কনটেন্ট, শিরোনাম, থাম্বনেইল ও বেসিক SEO নিয়ে প্রাথমিক পর্যালোচনা।"}
];